
/* Set the width of the side navigation to 250px */
function openNav() {
  // document.getElementById("navbarr").style.height = "100vh !important";
  $('.navbar').css("height","100vh", "important");
  document.getElementById("drawer").style.width = "550px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  // $('.navbar').css("background","transparent", "important");
  document.getElementById("drawer").style.width = "0";
  setTimeout(()=>{
    $('.navbar').css("height","120px", "important");
    // $('.navbar').css("background","rgba(256,256,256,.9)", "important");
  }, 400)
}

function myFunction1() {
  var elmnt = document.getElementById("features");
  elmnt.scrollIntoView();
}

function myFunction2() {
  var elmnt = document.getElementById("services");
  elmnt.scrollIntoView();
}


$('.slickk').slick({
  accessibility: false,
  infinite: true,
  slidesToShow: 1,
  autoplay: true,
  arrows: false,
  dots: false,
  swipeToSlide: true,
  infinite: false
});

$('.slickkk').slick({
  accessibility: false,
  infinite: true,
  slidesToShow: 4,
  autoplay: true,
  arrows: true,
  dots: false,
  swipeToSlide: true
});